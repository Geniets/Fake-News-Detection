# Website Credibility Model Retraining Guide
## Compatible with Image Deepfake Detection Model (NumPy 1.26.4)

---

## 🎯 **Overview**

This guide will help you retrain your website credibility classification model using versions compatible with your existing image deepfake detection model.

### **Key Compatibility Requirements:**
- ✅ **NumPy 1.26.4** (CRITICAL - required for TensorFlow/Keras compatibility)
- ✅ **Scikit-learn 1.5.2** (latest stable, works with NumPy 1.26.4)
- ✅ **XGBoost 2.1.3** (latest, no NumPy version conflicts)
- ✅ **TensorFlow 2.16.2** + **Keras 3.3.3** (for .keras model files)

---

## 📦 **Installation**

### **Option 1: Fresh Virtual Environment (Recommended)**

```bash
# Create new virtual environment
python -m venv model_env
source model_env/bin/activate  # On Windows: model_env\Scripts\activate

# Install all dependencies
pip install -r requirements.txt

# Verify NumPy version
python -c "import numpy; print(f'NumPy: {numpy.__version__}')"
# Should output: NumPy: 1.26.4
```

### **Option 2: Update Existing Environment**

```bash
# Activate your existing environment
source your_env/bin/activate

# Install/upgrade to compatible versions
pip install --upgrade numpy==1.26.4
pip install --upgrade scikit-learn==1.5.2
pip install --upgrade xgboost==2.1.3
pip install --upgrade pandas==2.2.3
pip install --upgrade joblib==1.4.2

# Verify installations
python -c "import numpy, sklearn, xgboost; print(f'NumPy: {numpy.__version__}, Scikit-learn: {sklearn.__version__}, XGBoost: {xgboost.__version__}')"
```

### **Option 3: Conda Environment**

```bash
# Create conda environment
conda create -n model_env python=3.12 numpy=1.26.4 -y
conda activate model_env

# Install ML packages
pip install scikit-learn==1.5.2 xgboost==2.1.3 pandas==2.2.3 joblib==1.4.2

# Install DL packages (if using image model)
pip install tensorflow==2.16.2 keras==3.3.3 pillow==11.0.0
```

---

## 🚀 **Retraining the Model**

### **Step 1: Prepare Your Data**

Place these files in the same directory as the training script:
- `trusted_sources_original.csv`
- `untrusted_sources.csv`
- `website_metadata_examples.csv`

### **Step 2: Run the Training Script**

```bash
python retrain_website_credibility_model.py
```

### **Step 3: Verify Output**

The script will create:
- ✅ `stacking_model.joblib` - The trained model
- ✅ `feature_names.joblib` - Feature names for prediction
- ✅ `model_metadata.json` - Model performance metrics

---

## 🔍 **What Changed from Original Training?**

### **Original Model Info:**
```json
{
  "model_name": "Stacking Ensemble (Reduced Features)",
  "accuracy": 0.875,
  "f1_score": 0.8636,
  "precision": 0.95,
  "recall": 0.7917,
  "num_features": 40,
  "base_models": ["Random Forest", "Gradient Boosting", "XGBoost"],
  "meta_learner": "Logistic Regression"
}
```

### **Key Differences:**
1. **NumPy Version**: Updated to 1.26.4 (from likely 2.x)
2. **Scikit-learn**: Updated to 1.5.2 (more stable)
3. **XGBoost**: Updated to 2.1.3 (latest)
4. **Training Process**: Identical algorithm and hyperparameters
5. **Expected Performance**: Should match or slightly exceed original (87.5% accuracy)

---

## 🧪 **Testing the Retrained Model**

### **Quick Test Script:**

```python
import joblib
import pandas as pd
import numpy as np

# Load model
model = joblib.load('stacking_model.joblib')
feature_names = joblib.load('feature_names.joblib')

# Load your test data
# Make sure to use the same feature engineering as training
test_data = pd.read_csv('your_test_data.csv')

# Predict
predictions = model.predict(test_data[feature_names])
probabilities = model.predict_proba(test_data[feature_names])

# Print results
for i in range(len(predictions)):
    label = "Trusted" if predictions[i] == 1 else "Untrusted"
    confidence = probabilities[i].max() * 100
    print(f"Website {i+1}: {label} (Confidence: {confidence:.1f}%)")
```

---

## 🔧 **Troubleshooting**

### **Problem: NumPy version conflicts**

```bash
# Uninstall all NumPy versions
pip uninstall numpy -y

# Reinstall exact version
pip install numpy==1.26.4

# Verify
python -c "import numpy; print(numpy.__version__)"
```

### **Problem: XGBoost import errors**

```bash
# Reinstall XGBoost
pip uninstall xgboost -y
pip install xgboost==2.1.3
```

### **Problem: Scikit-learn deprecation warnings**

These are normal and can be ignored. If you want to suppress them:

```python
import warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)
```

### **Problem: Different performance than original**

This can happen due to:
- Random seed differences
- Different synthetic data generation
- NumPy random number generation changes between versions

**Solution**: Run multiple training iterations and average results.

---

## 📊 **Performance Expectations**

### **Expected Metrics:**
- **Accuracy**: 85-88%
- **Precision**: 93-95%
- **Recall**: 78-82%
- **F1-Score**: 85-87%

### **Why These Metrics?**
The model is trained on data including:
- **Real websites**: ~23% of data
- **Normal synthetic websites**: ~53% of data  
- **Edge cases**: ~24% of data (intentionally difficult)

Edge cases include:
- Trusted sites with poor security metadata
- Sophisticated fake sites with professional infrastructure

87.5% accuracy with these edge cases is **excellent for production**.

---

## 🔄 **Integration with Image Model**

Both models now use **NumPy 1.26.4**, so they can coexist in the same environment:

```python
# Load both models in same script
import joblib
import keras
import numpy as np

# Website credibility model
web_model = joblib.load('stacking_model.joblib')
web_features = joblib.load('feature_names.joblib')

# Image deepfake model
image_model = keras.models.load_model('resnet50_best.keras')

print(f"NumPy version: {np.__version__}")  # Should be 1.26.4
print("✓ Both models loaded successfully!")

# Use both models
website_prediction = web_model.predict(web_data[web_features])
image_prediction = image_model.predict(image_data)
```

---

## 📝 **Version Summary**

| Package | Version | Purpose |
|---------|---------|---------|
| numpy | 1.26.4 | **CRITICAL** - Base numerical operations |
| scikit-learn | 1.5.2 | ML algorithms, preprocessing |
| xgboost | 2.1.3 | Gradient boosting base model |
| tensorflow | 2.16.2 | Deep learning backend |
| keras | 3.3.3 | High-level DL API (.keras files) |
| pandas | 2.2.3 | Data manipulation |
| joblib | 1.4.2 | Model serialization |

---

## 🎓 **Next Steps**

1. ✅ Install compatible versions
2. ✅ Run retraining script
3. ✅ Verify model performance
4. ✅ Test with your data
5. ✅ Deploy to production

---

## 💡 **Pro Tips**

### **Tip 1: Version Pinning**
Always use `requirements.txt` to ensure reproducibility:
```bash
pip freeze > requirements_frozen.txt
```

### **Tip 2: Environment Isolation**
Use separate virtual environments for development and production:
```bash
# Development
python -m venv dev_env

# Production
python -m venv prod_env
```

### **Tip 3: Model Versioning**
Save models with version numbers:
```python
import joblib
from datetime import datetime

version = datetime.now().strftime('%Y%m%d')
joblib.dump(model, f'stacking_model_v{version}.joblib')
```

### **Tip 4: Monitoring**
Track model performance over time:
```python
import json
from datetime import datetime

metrics = {
    'timestamp': datetime.now().isoformat(),
    'accuracy': float(accuracy),
    'f1_score': float(f1),
    'version': 'v20260208'
}

with open('model_performance_log.json', 'a') as f:
    f.write(json.dumps(metrics) + '\n')
```

---

## ❓ **FAQ**

**Q: Will this work with my existing .keras image model?**  
A: Yes! NumPy 1.26.4 is fully compatible with TensorFlow 2.16.2 and Keras 3.3.3.

**Q: Can I use Python 3.13?**  
A: Python 3.12 is recommended. Python 3.13 may have compatibility issues with some packages.

**Q: Why not use the latest NumPy 2.x?**  
A: TensorFlow 2.16.2 requires NumPy < 2.0. NumPy 1.26.4 is the latest compatible version.

**Q: How often should I retrain?**  
A: Retrain when:
- New data becomes available
- Model performance degrades
- Dependency versions change
- Feature set updates

**Q: Can I use GPU acceleration?**  
A: XGBoost and scikit-learn can use GPU with:
```bash
pip install xgboost[gpu]
```

---

## 📞 **Support**

If you encounter issues:
1. Check versions: `pip list | grep -E "(numpy|scikit-learn|xgboost)"`
2. Review error messages carefully
3. Verify data file formats match expected schema
4. Check Python version: `python --version` (should be 3.10-3.12)

---

**Last Updated**: February 8, 2026  
**Compatible with**: NumPy 1.26.4, TensorFlow 2.16.2, Keras 3.3.3
