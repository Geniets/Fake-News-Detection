#!/usr/bin/env python3
"""
Version Compatibility Checker
Verifies that all installed packages are compatible for both models
"""

import sys

def check_version(package_name, required_version, comparison='=='):
    """Check if a package version meets requirements"""
    try:
        module = __import__(package_name)
        installed_version = module.__version__
        
        if comparison == '==':
            is_compatible = installed_version == required_version
        elif comparison == '>=':
            is_compatible = tuple(map(int, installed_version.split('.'))) >= tuple(map(int, required_version.split('.')))
        elif comparison == '<':
            is_compatible = tuple(map(int, installed_version.split('.'))) < tuple(map(int, required_version.split('.')))
        else:
            is_compatible = False
        
        status = "✓" if is_compatible else "✗"
        color = "\033[92m" if is_compatible else "\033[91m"
        reset = "\033[0m"
        
        print(f"{color}{status}{reset} {package_name:20s} {installed_version:15s} (required: {comparison}{required_version})")
        return is_compatible
    except ImportError:
        print(f"✗ {package_name:20s} {'NOT INSTALLED':15s} (required: {comparison}{required_version})")
        return False
    except AttributeError:
        print(f"⚠ {package_name:20s} {'VERSION UNKNOWN':15s} (required: {comparison}{required_version})")
        return True  # Give benefit of doubt

def main():
    print("\n" + "=" * 80)
    print("PACKAGE VERSION COMPATIBILITY CHECKER")
    print("=" * 80)
    print()
    
    # Check Python version
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    python_compatible = sys.version_info.major == 3 and 10 <= sys.version_info.minor <= 12
    
    status = "✓" if python_compatible else "✗"
    color = "\033[92m" if python_compatible else "\033[91m"
    reset = "\033[0m"
    
    print(f"{color}{status}{reset} {'Python':20s} {python_version:15s} (required: 3.10-3.12)")
    print()
    
    # Critical packages
    print("CRITICAL PACKAGES (must match exactly):")
    print("-" * 80)
    
    results = []
    
    # NumPy is CRITICAL - must be 1.26.4
    results.append(check_version('numpy', '1.26.4', '=='))
    
    print()
    print("MACHINE LEARNING PACKAGES:")
    print("-" * 80)
    
    # ML packages
    results.append(check_version('sklearn', '1.5.2', '>='))
    results.append(check_version('xgboost', '2.1.0', '>='))
    results.append(check_version('pandas', '2.0.0', '>='))
    results.append(check_version('joblib', '1.0.0', '>='))
    
    print()
    print("DEEP LEARNING PACKAGES (for .keras model):")
    print("-" * 80)
    
    # DL packages
    results.append(check_version('tensorflow', '2.16.0', '>='))
    results.append(check_version('keras', '3.0.0', '>='))
    
    print()
    print("IMAGE PROCESSING:")
    print("-" * 80)
    
    # PIL/Pillow
    try:
        from PIL import Image
        import PIL
        pil_version = PIL.__version__
        print(f"✓ {'pillow':20s} {pil_version:15s}")
        results.append(True)
    except ImportError:
        print(f"✗ {'pillow':20s} {'NOT INSTALLED':15s}")
        results.append(False)
    
    print()
    print("=" * 80)
    
    # Summary
    if all(results) and python_compatible:
        print("✓ ALL CHECKS PASSED - Your environment is compatible!")
        print()
        print("You can now:")
        print("  1. Run: python retrain_website_credibility_model.py")
        print("  2. Load .keras models with: keras.models.load_model('model.keras')")
        print("  3. Use both models in the same environment")
    else:
        print("✗ SOME CHECKS FAILED - Please install/upgrade packages")
        print()
        print("To fix:")
        print("  pip install -r requirements.txt")
        print()
        if not python_compatible:
            print("⚠ WARNING: Your Python version may not be compatible.")
            print(f"  Current: Python {python_version}")
            print("  Required: Python 3.10, 3.11, or 3.12")
    
    print("=" * 80)
    print()

if __name__ == "__main__":
    main()
