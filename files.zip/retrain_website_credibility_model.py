"""
Website Credibility Model Retraining Script
Compatible with NumPy 1.26.4 (required for TensorFlow/Keras compatibility)
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# Print versions for verification
print("=" * 70)
print("ENVIRONMENT VERIFICATION")
print("=" * 70)
print(f"NumPy version: {np.__version__}")
try:
    import sklearn
    print(f"Scikit-learn version: {sklearn.__version__}")
except:
    print("Scikit-learn: NOT INSTALLED")

try:
    import xgboost as xgb
    print(f"XGBoost version: {xgb.__version__}")
    XGBOOST_AVAILABLE = True
except:
    print("XGBoost: NOT INSTALLED")
    XGBOOST_AVAILABLE = False

print("=" * 70)
print()

# Import required libraries
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.ensemble import (
    RandomForestClassifier, 
    GradientBoostingClassifier,
    StackingClassifier
)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, classification_report
)
import joblib
import json
from datetime import datetime


def load_data():
    """Load and prepare the datasets"""
    print("=" * 70)
    print("STEP 1: LOADING DATA")
    print("=" * 70)
    
    # Load datasets
    trusted_sources = pd.read_csv('trusted_sources_original.csv')
    untrusted_sources = pd.read_csv('untrusted_sources.csv')
    metadata = pd.read_csv('website_metadata_examples.csv')
    
    print(f"✓ Trusted sources: {len(trusted_sources)} records")
    print(f"✓ Untrusted sources: {len(untrusted_sources)} records")
    print(f"✓ Metadata: {len(metadata)} records")
    
    # Create labeled datasets
    trusted_labeled = trusted_sources[['domain']].copy()
    trusted_labeled['credibility_label'] = 1
    
    untrusted_labeled = untrusted_sources[['domain']].copy()
    untrusted_labeled['credibility_label'] = 0
    
    # Combine labels
    source_labels = pd.concat([trusted_labeled, untrusted_labeled], ignore_index=True)
    
    # Merge with metadata
    df = metadata.merge(source_labels, on='domain', how='inner')
    
    print(f"✓ Total samples: {len(df)}")
    print(f"✓ Class distribution:")
    print(df['credibility_label'].value_counts())
    print()
    
    return df


def generate_synthetic_data(df):
    """Generate synthetic websites to balance the dataset"""
    print("=" * 70)
    print("STEP 2: GENERATING SYNTHETIC DATA")
    print("=" * 70)
    
    np.random.seed(42)
    
    def generate_synthetic_websites(n_samples, credibility_label, edge_case=False):
        """Generate realistic synthetic website metadata"""
        
        synthetic_data = []
        label_name = "trusted" if credibility_label == 1 else "untrusted"
        
        for i in range(n_samples):
            # Generate domain name
            if credibility_label == 1:
                tld = np.random.choice(['.com', '.org', '.edu', '.gov', '.net'], 
                                     p=[0.4, 0.3, 0.15, 0.1, 0.05])
                prefix = np.random.choice(['news', 'times', 'press', 'daily', 'post', 
                                         'journal', 'herald', 'tribune'])
                suffix = np.random.choice(['', 'central', 'network', 'today', 'weekly', 
                                         str(np.random.randint(1,100))])
                domain = f"{prefix}{suffix}{tld}".replace(" ", "")
            else:
                tld = np.random.choice(['.com', '.news', '.info', '.co', '.net'], 
                                     p=[0.5, 0.2, 0.15, 0.1, 0.05])
                prefix = np.random.choice(['real', 'true', 'patriot', 'freedom', 'alert', 
                                         'wake', 'natural', 'truth'])
                suffix = np.random.choice(['news', 'daily', 'report', 'feed', 'central', 
                                         'insider', str(np.random.randint(1,100))])
                domain = f"{prefix}{suffix}{tld}".replace(" ", "")
            
            # Quality factor determines overall metadata quality
            if edge_case:
                if credibility_label == 1:
                    quality = np.random.beta(2, 4)  # Trusted but poor metadata
                else:
                    quality = np.random.beta(6, 2)  # Untrusted but good metadata
            else:
                if credibility_label == 1:
                    quality = np.random.beta(7, 2)  # High quality
                else:
                    quality = np.random.beta(2, 5)  # Low quality
            
            # Generate metadata based on quality factor
            record = {
                'domain': f"synthetic_{'edge_' if edge_case else ''}{label_name}_{i:03d}_{domain}",
                'credibility_label': credibility_label,
                'has_https': 'Yes' if np.random.random() < (0.95 if credibility_label == 1 else 0.70) * (0.7 if edge_case else 1.0) else 'No',
                'ssl_valid': 'Yes' if np.random.random() < (0.92 if credibility_label == 1 else 0.60) * (0.8 if edge_case else 1.0) else 'No',
                'ssl_issuer': np.random.choice(
                    ["Let's Encrypt", 'DigiCert', 'GlobalSign', 'Comodo', 'GeoTrust'] 
                    if (credibility_label == 1 and not edge_case) or (credibility_label == 0 and edge_case)
                    else ["Let's Encrypt", 'Self-signed', 'Unknown', 'Cloudflare']
                ),
                'tls_version': np.random.choice(
                    ['TLS 1.3', 'TLS 1.2'] 
                    if (credibility_label == 1 and not edge_case) or (credibility_label == 0 and edge_case)
                    else ['TLS 1.2', 'TLS 1.1', 'TLS 1.0', 'none']
                ),
                'certificate_type': np.random.choice(
                    ['EV', 'OV', 'DV'] 
                    if (credibility_label == 1 and not edge_case) or (credibility_label == 0 and edge_case)
                    else ['DV', 'none', 'self_signed']
                ),
                'domain_age_years': np.random.exponential(20 if credibility_label == 1 else 5) 
                                   if not edge_case else np.random.exponential(8),
                'domain_registrar': np.random.choice(
                    ['GoDaddy', 'Namecheap', 'Google Domains', 'Network Solutions']
                ),
                'alexa_rank': int(np.random.exponential(100000 if credibility_label == 1 else 500000)),
                'page_rank': np.random.beta(8, 2) if credibility_label == 1 else np.random.beta(2, 5),
                'num_external_links': int(np.random.exponential(50 if credibility_label == 1 else 20)),
                'num_internal_links': int(np.random.exponential(100 if credibility_label == 1 else 30)),
                'has_contact_page': 'Yes' if np.random.random() < (0.9 if credibility_label == 1 else 0.4) else 'No',
                'has_privacy_policy': 'Yes' if np.random.random() < (0.95 if credibility_label == 1 else 0.5) else 'No',
                'has_about_page': 'Yes' if np.random.random() < (0.9 if credibility_label == 1 else 0.6) else 'No',
            }
            
            synthetic_data.append(record)
        
        return pd.DataFrame(synthetic_data)
    
    # Generate balanced synthetic data
    n_trusted_normal = 62
    n_trusted_edge = 28
    n_untrusted_normal = 65
    n_untrusted_edge = 29
    
    # Generate datasets
    trusted_normal = generate_synthetic_websites(n_trusted_normal, 1, edge_case=False)
    trusted_edge = generate_synthetic_websites(n_trusted_edge, 1, edge_case=True)
    untrusted_normal = generate_synthetic_websites(n_untrusted_normal, 0, edge_case=False)
    untrusted_edge = generate_synthetic_websites(n_untrusted_edge, 0, edge_case=True)
    
    print(f"✓ Generated {len(trusted_normal)} normal trusted websites")
    print(f"✓ Generated {len(trusted_edge)} edge case trusted websites")
    print(f"✓ Generated {len(untrusted_normal)} normal untrusted websites")
    print(f"✓ Generated {len(untrusted_edge)} edge case untrusted websites")
    
    # Sample real websites
    real_trusted = df[df['credibility_label'] == 1].sample(n=30, random_state=42)
    real_untrusted = df[df['credibility_label'] == 0].sample(n=26, random_state=42)
    
    # Combine all data
    final_df = pd.concat([
        real_trusted, real_untrusted,
        trusted_normal, trusted_edge,
        untrusted_normal, untrusted_edge
    ], ignore_index=True)
    
    print(f"\n✓ Final dataset: {len(final_df)} samples")
    print(f"  - Real websites: {len(real_trusted) + len(real_untrusted)}")
    print(f"  - Synthetic websites: {len(trusted_normal) + len(trusted_edge) + len(untrusted_normal) + len(untrusted_edge)}")
    print(f"\n✓ Class balance:")
    print(final_df['credibility_label'].value_counts())
    print()
    
    return final_df


def feature_engineering(df):
    """Perform feature engineering"""
    print("=" * 70)
    print("STEP 3: FEATURE ENGINEERING")
    print("=" * 70)
    
    # Create domain age buckets
    df['domain_age_bucket'] = pd.cut(
        df['domain_age_years'], 
        bins=[0, 1, 3, 5, 10, float('inf')],
        labels=['very_new', 'new', 'established', 'mature', 'legacy']
    )
    
    # Binary features
    binary_mappings = {
        'has_https': {'Yes': 1, 'No': 0},
        'ssl_valid': {'Yes': 1, 'No': 0},
        'has_contact_page': {'Yes': 1, 'No': 0},
        'has_privacy_policy': {'Yes': 1, 'No': 0},
        'has_about_page': {'Yes': 1, 'No': 0}
    }
    
    for col, mapping in binary_mappings.items():
        if col in df.columns:
            df[col] = df[col].map(mapping)
    
    # One-hot encoding for categorical features
    categorical_features = ['ssl_issuer', 'tls_version', 'certificate_type', 
                           'domain_registrar', 'domain_age_bucket']
    
    df_encoded = pd.get_dummies(df, columns=categorical_features, prefix=categorical_features)
    
    print(f"✓ Features after encoding: {df_encoded.shape[1]}")
    print()
    
    return df_encoded


def train_model(X_train, X_test, y_train, y_test, feature_names):
    """Train the stacking ensemble model"""
    print("=" * 70)
    print("STEP 4: TRAINING STACKING ENSEMBLE")
    print("=" * 70)
    
    # Base models
    print("\nTraining base models:")
    print("  1. Random Forest")
    rf = RandomForestClassifier(
        n_estimators=300,
        max_depth=20,
        min_samples_split=5,
        min_samples_leaf=2,
        max_features='sqrt',
        class_weight='balanced',
        random_state=42,
        n_jobs=-1
    )
    
    print("  2. Gradient Boosting")
    gb = GradientBoostingClassifier(
        n_estimators=200,
        max_depth=5,
        learning_rate=0.1,
        subsample=0.8,
        random_state=42
    )
    
    base_estimators = [
        ('rf', rf),
        ('gb', gb)
    ]
    
    if XGBOOST_AVAILABLE:
        print("  3. XGBoost")
        xgb_model = xgb.XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            eval_metric='logloss',
            use_label_encoder=False
        )
        base_estimators.append(('xgb', xgb_model))
    
    # Meta-learner
    print("  Meta-learner: Logistic Regression")
    meta_learner = LogisticRegression(max_iter=1000, random_state=42, C=1.0)
    
    # Stacking classifier
    stacking_clf = StackingClassifier(
        estimators=base_estimators,
        final_estimator=meta_learner,
        cv=5,
        n_jobs=-1
    )
    
    print("\nTraining stacking ensemble...")
    stacking_clf.fit(X_train, y_train)
    
    # Evaluate
    print("\n" + "=" * 70)
    print("STEP 5: EVALUATION")
    print("=" * 70)
    
    y_pred = stacking_clf.predict(X_test)
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    
    print(f"\n✓ Model Performance:")
    print(f"  Accuracy:  {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"  Precision: {precision:.4f}")
    print(f"  Recall:    {recall:.4f}")
    print(f"  F1-Score:  {f1:.4f}")
    
    print(f"\n{classification_report(y_test, y_pred, target_names=['Untrusted', 'Trusted'])}")
    
    return stacking_clf, accuracy, precision, recall, f1


def save_model(model, feature_names, accuracy, precision, recall, f1):
    """Save the trained model and metadata"""
    print("=" * 70)
    print("STEP 6: SAVING MODEL")
    print("=" * 70)
    
    # Save model
    joblib.dump(model, 'stacking_model.joblib')
    print("✓ Model saved: stacking_model.joblib")
    
    # Save feature names
    joblib.dump(feature_names, 'feature_names.joblib')
    print("✓ Features saved: feature_names.joblib")
    
    # Save metadata
    base_models = ['Random Forest', 'Gradient Boosting']
    if XGBOOST_AVAILABLE:
        base_models.append('XGBoost')
    
    metadata = {
        'model_name': 'Stacking Ensemble (Reduced Features)',
        'accuracy': float(accuracy),
        'f1_score': float(f1),
        'precision': float(precision),
        'recall': float(recall),
        'num_features': len(feature_names),
        'base_models': base_models,
        'meta_learner': 'Logistic Regression',
        'training_date': datetime.now().strftime('%Y-%m-%d'),
        'numpy_version': np.__version__,
        'sklearn_version': sklearn.__version__
    }
    
    with open('model_metadata.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    print("✓ Metadata saved: model_metadata.json")
    print()


def main():
    """Main training pipeline"""
    print("\n" + "=" * 70)
    print("WEBSITE CREDIBILITY MODEL RETRAINING")
    print("Compatible with NumPy 1.26.4 and TensorFlow/Keras")
    print("=" * 70)
    print()
    
    # Load data
    df = load_data()
    
    # Generate synthetic data
    df_final = generate_synthetic_data(df)
    
    # Feature engineering
    df_encoded = feature_engineering(df_final)
    
    # Prepare features and target
    X = df_encoded.drop(['domain', 'credibility_label'], axis=1)
    y = df_encoded['credibility_label']
    
    feature_names = X.columns.tolist()
    
    # Feature selection - use top 40 features
    print("=" * 70)
    print("FEATURE SELECTION")
    print("=" * 70)
    
    from sklearn.ensemble import RandomForestClassifier
    
    # Fit a quick RF to get feature importances
    rf_temp = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    rf_temp.fit(X, y)
    
    # Get feature importances
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': rf_temp.feature_importances_
    }).sort_values('importance', ascending=False)
    
    # Select top 40 features
    top_features = feature_importance.head(40)['feature'].tolist()
    X_reduced = X[top_features]
    
    print(f"✓ Selected top {len(top_features)} features")
    print(f"  Total importance captured: {feature_importance.head(40)['importance'].sum():.4f}")
    print()
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X_reduced, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"✓ Train set: {len(X_train)} samples")
    print(f"✓ Test set: {len(X_test)} samples")
    print()
    
    # Train model
    model, accuracy, precision, recall, f1 = train_model(
        X_train, X_test, y_train, y_test, top_features
    )
    
    # Save model
    save_model(model, top_features, accuracy, precision, recall, f1)
    
    # Test loading
    print("=" * 70)
    print("VERIFICATION: TESTING MODEL LOADING")
    print("=" * 70)
    
    loaded_model = joblib.load('stacking_model.joblib')
    loaded_features = joblib.load('feature_names.joblib')
    
    # Test prediction
    sample_prediction = loaded_model.predict(X_test[:5])
    sample_proba = loaded_model.predict_proba(X_test[:5])
    
    print(f"\n✓ Model loaded successfully!")
    print(f"✓ Features loaded: {len(loaded_features)}")
    print(f"\nTest predictions on 5 samples:")
    for i in range(5):
        pred_label = "Trusted" if sample_prediction[i] == 1 else "Untrusted"
        confidence = sample_proba[i].max() * 100
        print(f"  Sample {i+1}: {pred_label} (Confidence: {confidence:.1f}%)")
    
    print("\n" + "=" * 70)
    print("TRAINING COMPLETE!")
    print("=" * 70)
    print("\nFiles created:")
    print("  - stacking_model.joblib")
    print("  - feature_names.joblib")
    print("  - model_metadata.json")
    print()


if __name__ == "__main__":
    main()
